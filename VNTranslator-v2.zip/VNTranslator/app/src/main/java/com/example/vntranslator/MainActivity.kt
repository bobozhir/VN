package com.example.vntranslator

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var backendGroup: RadioGroup
    private val reqProjection = 1
    private val reqNotif = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "VN Переводчик"; textSize = 24f })

        backendGroup = RadioGroup(this)
        backendGroup.addView(RadioButton(this).apply { text = "Gemini (бесплатный ключ, лучшее качество)"; id = 201 })
        backendGroup.addView(RadioButton(this).apply { text = "Офлайн ML Kit (без ключа, качество проще)"; id = 202 })
        backendGroup.check(if (prefs.getString("backend", "gemini") == "mlkit") 202 else 201)
        root.addView(backendGroup)

        keyEdit = EditText(this).apply {
            hint = "Gemini API key (aistudio.google.com/apikey)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("gkey", ""))
        }
        root.addView(keyEdit)

        modelEdit = EditText(this).apply {
            hint = "Модель Gemini (по умолчанию ${Translator.DEFAULT_GEMINI_MODEL})"
            setText(prefs.getString("gmodel", ""))
        }
        root.addView(modelEdit)

        root.addView(Button(this).apply { text = "Запустить"; setOnClickListener { begin() } })
        root.addView(Button(this).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        root.addView(TextView(this).apply {
            textSize = 15f
            text = "\n1) Выбери переводчик, при Gemini вставь бесплатный ключ. Нажми «Запустить».\n" +
                "2) В системном окне выбери «Весь экран».\n" +
                "3) Открой новеллу. Появится кнопка RU (её можно перетащить).\n\n" +
                "• Первый тап по RU: обведи рамкой ТЕКСТОВОЕ ОКНО новеллы. После этого включается авто-режим: " +
                "новые реплики переводятся сами, перевод появляется над окном (или под ним).\n" +
                "• Кнопка зелёная — авто-режим включён. Тап по RU — пауза / продолжить.\n" +
                "• Долгое нажатие на RU — выбрать другую область.\n" +
                "• Тап по переводу — скрыть его до следующей реплики.\n\n" +
                "Если Gemini недоступен (лимит или ошибка), приложение само переключится на офлайн-перевод. " +
                "Офлайн-модель (~30 МБ) скачивается при первом запуске, нужен интернет."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun begin() {
        val backend = if (backendGroup.checkedRadioButtonId == 202) "mlkit" else "gemini"
        val key = keyEdit.text.toString().trim()
        if (backend == "gemini" && key.isEmpty()) {
            toast("Вставь ключ Gemini или выбери офлайн-режим"); return
        }
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putString("backend", backend)
            .putString("gkey", key)
            .putString("gmodel", modelEdit.text.toString().trim())
            .apply()

        if (!Settings.canDrawOverlays(this)) {
            toast("Разреши показ поверх других приложений и вернись")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java).putExtra("code", resultCode).putExtra("data", data)
            )
            toast("Готово! Открой новеллу — там кнопка RU")
            moveTaskToBack(true)
        }
    }
}
