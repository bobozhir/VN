package com.example.vntranslator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Полноэкранный "замороженный" скриншот, на котором пользователь обводит область. */
class SelectionView(
    ctx: Context,
    private val shot: Bitmap,
    private val onDone: (Rect?) -> Unit
) : View(ctx) {

    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 44f; textAlign = Paint.Align.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val dst = RectF()
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var active = false

    override fun onDraw(c: Canvas) {
        dst.set(0f, 0f, width.toFloat(), height.toFloat())
        c.drawBitmap(shot, null, dst, null)
        c.drawRect(dst, dim)
        if (active) {
            val l = min(sx, ex); val t = min(sy, ey)
            val r = max(sx, ex); val b = max(sy, ey)
            c.save()
            c.clipRect(l, t, r, b)
            c.drawBitmap(shot, null, dst, null)
            c.restore()
            c.drawRect(l, t, r, b, border)
        } else {
            c.drawText("Обведи область с текстом (тап — отмена)", width / 2f, height / 2f, hint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; ex = sx; ey = sy
                active = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y
                active = false
                val l = min(sx, ex).toInt(); val t = min(sy, ey).toInt()
                val r = max(sx, ex).toInt(); val b = max(sy, ey).toInt()
                if (r - l < 40 || b - t < 40) onDone(null) else onDone(Rect(l, t, r, b))
            }
            MotionEvent.ACTION_CANCEL -> {
                active = false
                onDone(null)
            }
        }
        return true
    }
}
