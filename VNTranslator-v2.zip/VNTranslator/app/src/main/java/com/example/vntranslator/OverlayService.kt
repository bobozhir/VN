package com.example.vntranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.abs

private typealias LP = WindowManager.LayoutParams

private const val SIG_W = 96
private const val SIG_H = 32
private const val TICK_MS = 400L
private const val COLOR_IDLE = 0xFF5B4BFF.toInt()
private const val COLOR_AUTO = 0xFF1DB954.toInt()

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val imgThread = HandlerThread("vn-frames").apply { start() }
    private val imgHandler = Handler(imgThread.looper)
    private val worker = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    // захват экрана
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    @Volatile private var latest: Bitmap? = null

    // интерфейс
    private var bubble: TextView? = null
    private var bubbleBg: GradientDrawable? = null
    private var selection: SelectionView? = null
    private var pendingShot: Bitmap? = null
    private var resultView: TextView? = null

    // авто-режим
    private var area: RectF? = null
    private var auto = false
    private var prevTick: IntArray? = null
    private var processedSig: IntArray? = null
    private var stableTicks = 0
    private var unstableTicks = 0
    private var needProcess = false
    private var busy = false
    private var lastText = ""
    private var lastFallbackToast = 0L
    private val cache = ConcurrentHashMap<String, String>()
    private val history = ArrayList<String>()

    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            try { step() } catch (e: Exception) { /* пропускаем кадр */ }
            ui.postDelayed(this, TICK_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        goForeground()

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { ui.post { stopSelf() } }
        }, ui)

        setupCapture(p)
        showBubble()

        // заранее качаем офлайн-модель (она же запасной вариант, если Gemini недоступен)
        val offlineOnly = getSharedPreferences("cfg", MODE_PRIVATE).getString("backend", "gemini") == "mlkit"
        worker.execute {
            val ok = Translator.prepareOffline()
            if (!ok && offlineOnly) ui.post { toast("Офлайн-модель не скачалась: подключись к интернету") }
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vn", "VN Переводчик", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "vn")
            .setContentTitle("VN Переводчик работает")
            .setContentText("Кнопка RU поверх экрана. «Стоп» — выключить.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Стоп", stopPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- захват экрана ----------

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun buildReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try {
                    val pl = img.planes[0]
                    val rowPadding = pl.rowStride - pl.pixelStride * w
                    val bmp = Bitmap.createBitmap(w + rowPadding / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(pl.buffer)
                    latest = if (rowPadding == 0) bmp
                    else Bitmap.createBitmap(bmp, 0, 0, w, h).also { bmp.recycle() }
                } finally {
                    img.close()
                }
            }
        }, imgHandler)
        return r
    }

    private fun setupCapture(p: MediaProjection) {
        val (w, h) = screenSize()
        sw = w; sh = h
        val r = buildReader(w, h)
        reader = r
        vd = p.createVirtualDisplay(
            "vn-capture", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Возвращает true, если экран повернули и захват пришлось перестроить. */
    private fun ensureSize(): Boolean {
        val (w, h) = screenSize()
        if (w == sw && h == sh) return false
        sw = w; sh = h
        val old = reader
        val r = buildReader(w, h)
        reader = r
        vd?.resize(w, h, resources.displayMetrics.densityDpi)
        vd?.surface = r.surface
        old?.close()
        latest = null
        return true
    }

    // ---------- кнопка ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun showBubble() {
        val size = dp(52)
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(COLOR_IDLE) }
        bubbleBg = bg
        val tv = TextView(this).apply {
            text = "RU"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            alpha = 0.85f
            background = bg
        }
        val lp = LP(size, size, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(160)
        }

        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0
        var moved = false; var longDone = false
        val longPress = Runnable { if (!moved) { longDone = true; startSelection() } }

        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false; longDone = false
                    ui.postDelayed(longPress, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > 12 || abs(e.rawY - downY) > 12) {
                        moved = true
                        ui.removeCallbacks(longPress)
                    }
                    if (moved) {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longPress)
                    if (!moved && !longDone) onBubbleTap()
                }
                MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun onBubbleTap() {
        when {
            area == null -> startSelection()
            auto -> { stopAuto(); toast("Авто-перевод на паузе") }
            else -> startAuto()
        }
    }

    // ---------- выбор области ----------

    private fun startSelection() {
        if (selection != null) return
        stopAuto()
        ensureSize()
        bubble?.visibility = View.INVISIBLE
        ui.postDelayed({
            val shot = latest
            if (shot == null) {
                bubble?.visibility = View.VISIBLE
                toast("Не удалось получить кадр, попробуй ещё раз")
                return@postDelayed
            }
            showSelection(shot)
        }, 350)
    }

    private fun showSelection(shot: Bitmap) {
        pendingShot = shot
        val v = SelectionView(this, shot) { rect -> ui.post { onSelected(rect) } }
        val lp = LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(v, lp)
        selection = v
    }

    private fun removeSelection() {
        selection?.let { runCatching { wm.removeView(it) } }
        selection = null
        pendingShot = null
    }

    private fun onSelected(rect: Rect?) {
        val sel = selection ?: return
        val vw = sel.width.toFloat()
        val vh = sel.height.toFloat()
        removeSelection()
        bubble?.visibility = View.VISIBLE
        if (rect == null || vw <= 0f || vh <= 0f) return
        area = RectF(rect.left / vw, rect.top / vh, rect.right / vw, rect.bottom / vh)
        startAuto()
    }

    // ---------- авто-режим ----------

    private fun startAuto() {
        if (area == null) return
        auto = true
        prevTick = null; processedSig = null
        stableTicks = 0; unstableTicks = 0
        needProcess = false
        lastText = ""
        bubbleBg?.setColor(COLOR_AUTO)
        ui.removeCallbacks(tick)
        ui.post(tick)
        toast("Авто-перевод включён")
    }

    private fun stopAuto() {
        auto = false
        ui.removeCallbacks(tick)
        clearResult()
        bubbleBg?.setColor(COLOR_IDLE)
    }

    private fun regionOf(shot: Bitmap, f: RectF): Rect {
        val l = (f.left * shot.width).toInt().coerceIn(0, shot.width - 2)
        val t = (f.top * shot.height).toInt().coerceIn(0, shot.height - 2)
        val r = (f.right * shot.width).toInt().coerceIn(l + 1, shot.width)
        val b = (f.bottom * shot.height).toInt().coerceIn(t + 1, shot.height)
        return Rect(l, t, r, b)
    }

    /** Грубый "отпечаток" области: средняя яркость по сетке. Нужен, чтобы замечать смену текста без OCR. */
    private fun signature(shot: Bitmap, rg: Rect): IntArray {
        val w = rg.width()
        val h = rg.height()
        val px = IntArray(w * h)
        shot.getPixels(px, 0, w, rg.left, rg.top, w, h)
        val sum = LongArray(SIG_W * SIG_H)
        val cnt = IntArray(SIG_W * SIG_H)
        var y = 0
        while (y < h) {
            val gy = y * SIG_H / h
            var x = 0
            while (x < w) {
                val gx = x * SIG_W / w
                val c = px[y * w + x]
                val lum = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                sum[gy * SIG_W + gx] += lum.toLong()
                cnt[gy * SIG_W + gx]++
                x += 2
            }
            y += 2
        }
        return IntArray(sum.size) { i -> if (cnt[i] == 0) 0 else (sum[i] / cnt[i]).toInt() }
    }

    private fun cells(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 30) n++
        return n
    }

    private fun step() {
        if (ensureSize()) {
            clearResult()
            prevTick = null; processedSig = null
            lastText = ""; needProcess = false
        }
        val shot = latest ?: return
        val f = area ?: return
        val rg = regionOf(shot, f)
        val sig = signature(shot, rg)

        val prev = prevTick
        prevTick = sig
        val changedNow = prev == null || cells(sig, prev) >= 2
        if (changedNow) {
            stableTicks = 0
            val ps = processedSig
            if (ps == null || cells(sig, ps) >= 2) needProcess = true
            if (needProcess) unstableTicks++
        } else {
            stableTicks++
        }

        // обрабатываем, когда текст "устоялся" (закончилась печать по буквам) или слишком долго меняется
        if (needProcess && !busy && (stableTicks >= 1 || unstableTicks > 6)) {
            needProcess = false
            unstableTicks = 0
            busy = true
            processedSig = sig
            val crop = Bitmap.createBitmap(shot, rg.left, rg.top, rg.width(), rg.height())
            process(crop)
        }
    }

    private fun process(crop: Bitmap) {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val backend = prefs.getString("backend", "gemini") ?: "gemini"
        val key = prefs.getString("gkey", "") ?: ""
        val gModel = (prefs.getString("gmodel", "") ?: "").ifBlank { Translator.DEFAULT_GEMINI_MODEL }
        val ctx = ArrayList(history.takeLast(5))
        val prevText = lastText
        if (resultView == null && lastText.isEmpty()) showResult("…")

        worker.execute {
            var norm = ""
            var tr: String? = null
            var err: String? = null
            try {
                val raw = Tasks.await(recognizer.process(InputImage.fromBitmap(crop, 0))).text.trim()
                norm = raw.replace(Regex("\\s+"), " ")
                if (norm.length >= 2 && norm != prevText) {
                    tr = cache[norm] ?: translateText(backend, key, gModel, raw, ctx)
                }
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            } finally {
                crop.recycle()
            }
            val n = norm
            val t = tr
            val er = err
            ui.post {
                busy = false
                if (!auto) return@post
                if (er != null) { showResult("⚠ $er"); return@post }
                if (needProcess) return@post // уже пришла новая реплика
                when {
                    n.length < 2 -> { lastText = ""; clearResult() }
                    t == null -> { /* тот же текст, что и раньше */ }
                    else -> {
                        cache[n] = t
                        lastText = n
                        showResult(t)
                        if (!t.startsWith("[")) {
                            history.add(t)
                            if (history.size > 20) history.removeAt(0)
                        }
                    }
                }
            }
        }
    }

    /** Вызывается в фоновом потоке. Gemini, при ошибке (лимит и т.п.) запасной вариант — офлайн. */
    private fun translateText(backend: String, key: String, model: String, text: String, ctx: List<String>): String {
        if (backend == "gemini" && key.isNotEmpty()) {
            try {
                return Translator.gemini(key, model, text, ctx)
            } catch (e: Exception) {
                val off = try { Translator.offline(text) } catch (e2: Exception) { null } ?: throw e
                val now = System.currentTimeMillis()
                if (now - lastFallbackToast > 30000) {
                    lastFallbackToast = now
                    val m = e.message?.take(90) ?: "ошибка"
                    ui.post { toast("Gemini: $m → офлайн-перевод") }
                }
                return off
            }
        }
        return Translator.offline(text)
    }

    // ---------- перевод на экране ----------

    /** Перевод показывается над областью (или под ней), чтобы не попадать в кадр и не мешать OCR. */
    private fun showResult(msg: String) {
        clearResult()
        val a = area ?: return
        val left = (a.left * sw).toInt()
        val topPx = (a.top * sh).toInt()
        val bottomPx = (a.bottom * sh).toInt()
        val areaW = ((a.right - a.left) * sw).toInt()
        val margin = dp(6)
        val above = topPx >= sh - bottomPx
        val avail = ((if (above) topPx else sh - bottomPx) - margin * 2).coerceAtLeast(dp(80))

        val tv = TextView(this).apply {
            text = msg
            setTextColor(Color.WHITE)
            textSize = 17f
            setPadding(dp(12), dp(8), dp(12), dp(10))
            maxHeight = avail
            ellipsize = TextUtils.TruncateAt.END
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(0xE6101018.toInt())
            }
            setOnClickListener { clearResult() }
        }
        val lp = LP(
            maxOf(areaW, dp(240)).coerceAtMost(sw), LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (above) {
                gravity = Gravity.BOTTOM or Gravity.START
                y = sh - topPx + margin
            } else {
                gravity = Gravity.TOP or Gravity.START
                y = bottomPx + margin
            }
            x = left
        }
        wm.addView(tv, lp)
        resultView = tv
    }

    private fun clearResult() {
        resultView?.let { runCatching { wm.removeView(it) } }
        resultView = null
    }

    override fun onDestroy() {
        auto = false
        ui.removeCallbacks(tick)
        clearResult()
        removeSelection()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        worker.shutdownNow()
        recognizer.close()
        vd?.release()
        reader?.close()
        projection?.stop()
        imgThread.quitSafely()
        super.onDestroy()
    }
}
