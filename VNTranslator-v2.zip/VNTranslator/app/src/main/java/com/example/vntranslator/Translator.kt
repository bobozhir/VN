package com.example.vntranslator

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Два бесплатных переводчика: Gemini (бесплатный ключ) и офлайн ML Kit. Все методы блокирующие. */
object Translator {
    /** Алиас "последний Flash". Если Google его переименует, имя можно поменять в настройках приложения. */
    const val DEFAULT_GEMINI_MODEL = "gemini-flash-latest"

    private val SYSTEM = """
        You are a professional literary translator of visual novels from English into Russian.
        You receive text recognized by OCR from a visual novel's text box (dialogue and/or narration, sometimes with a speaker name on the first short line).
        Line breaks in the input are only layout wraps. The OCR may contain small mistakes; silently fix obvious ones.
        Translate into natural, vivid, idiomatic Russian, the way a skilled human translator would.
        - Preserve each character's voice, register, humor, sarcasm, wordplay and emotional nuance. Avoid literal calques and stiff machine-translation phrasing.
        - Keep character names consistent with the earlier lines given as context (use the usual Russian transliteration).
        - If a speaker name is present, output "Имя: реплика".
        - Do not add notes, explanations, alternatives or the original English text.
        - If the input is not meaningful game text (UI junk, random symbols), reply with exactly: [нет текста]
        Output only the Russian translation.
    """.trimIndent()

    // ---------- офлайн (ML Kit) ----------

    private val mlTranslator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.RUSSIAN)
                .build()
        )
    }

    @Volatile private var mlReady = false

    /** Скачивает офлайн-модель (около 30 МБ, нужен интернет только один раз). */
    fun prepareOffline(): Boolean {
        if (mlReady) return true
        return try {
            Tasks.await(mlTranslator.downloadModelIfNeeded(DownloadConditions.Builder().build()))
            mlReady = true
            true
        } catch (e: Exception) {
            false
        }
    }

    fun offline(text: String): String {
        if (!prepareOffline()) throw RuntimeException("офлайн-модель не скачана (нужен интернет один раз)")
        return Tasks.await(mlTranslator.translate(text.replace("\n", " "))).trim()
    }

    // ---------- Gemini (бесплатный ключ из Google AI Studio) ----------

    fun gemini(apiKey: String, model: String, text: String, history: List<String>): String {
        val prompt = buildString {
            if (history.isNotEmpty()) {
                append("Context: previous lines (already in Russian) from this same game, for consistency of names and tone. Do not repeat them:\n")
                history.forEach { append("- ").append(it.take(400).replace("\n", " ")).append('\n') }
                append('\n')
            }
            append("Recognized text:\n<<<\n").append(text).append("\n>>>\nTranslate it into Russian.")
        }

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )
            )
            .put("generationConfig", JSONObject().put("temperature", 0.4))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(resp).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                resp.take(200)
            }
            throw RuntimeException("HTTP $code: $msg")
        }

        val cands = JSONObject(resp).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw RuntimeException("пустой ответ (возможно, фильтр безопасности)")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw RuntimeException("пустой ответ")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val out = sb.toString().trim()
        if (out.isEmpty()) throw RuntimeException("пустой ответ")
        return out
    }
}
